# 9axes.github.io
The 9axes Political Quiz measures individuals' political values across 9 axes.
